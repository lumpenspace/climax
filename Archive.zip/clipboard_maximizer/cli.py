import click
from clipboard_manager import copy_to_clipboard

@click.command()
@click.argument('files', nargs=-1, type=click.Path(exists=True))
def main(files):
    copy_to_clipboard(files)

if __name__ == '__main__':
    main()